package com.personal.budget_plus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgetPlusApplicationTests {

	@Test
	void contextLoads() {
	}

}
