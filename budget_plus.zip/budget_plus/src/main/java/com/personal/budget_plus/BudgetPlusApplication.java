package com.personal.budget_plus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BudgetPlusApplication {

	public static void main(String[] args) {
		SpringApplication.run(BudgetPlusApplication.class, args);
	}

}
